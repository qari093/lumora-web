import Link from "next/link";

export default function PrivateAccessPage({ searchParams }: { searchParams?: { next?: string } }) {
  const next = searchParams?.next ?? "/";
  return (
    <main style={{ padding: 24, maxWidth: 720, margin: "0 auto", fontFamily: "system-ui, -apple-system, Segoe UI, Roboto" }}>
      <h1 style={{ marginBottom: 8 }}>Private Access Required</h1>
      <p style={{ opacity: 0.9, lineHeight: 1.5 }}>
        This Lumora build is currently in <strong>Private Live</strong>.
        If you have an invite link, open it to unlock access on this device.
      </p>
      <div style={{ marginTop: 16, padding: 16, border: "1px solid rgba(255,255,255,0.15)", borderRadius: 12 }}>
        <p style={{ margin: 0, opacity: 0.9 }}>
          Ask the operator for an invite URL containing <code>?access=TOKEN</code>.
        </p>
        <p style={{ marginTop: 12, opacity: 0.8 }}>
          After unlocking, you will be redirected to: <code>{next}</code>
        </p>
        <div style={{ marginTop: 14 }}>
          <Link href="/" style={{ textDecoration: "underline" }}>Go to home</Link>
        </div>
      </div>
    </main>
  );
}
