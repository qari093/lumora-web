import CampaignTable from "../../components/ads/CampaignTable";
export const dynamic = "force-dynamic";
export default function CampaignsPage(){
  return (
    <div style={{padding:24}}>
      <CampaignTable />
    </div>
  );
}
