export function LumaSpaceStateBanner() {
  return null;
}
export default LumaSpaceStateBanner;
