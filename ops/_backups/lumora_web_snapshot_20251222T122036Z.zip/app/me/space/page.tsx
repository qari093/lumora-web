export default function MeSpacePage() {
  return <div style={{ padding: 24 }}>My space placeholder.</div>;
}
