/* NOTE: Add preload link manually if layout does not render <head> */
import { SplashGate } from "./_client/brand/SplashGate";
// FILE: app/layout.tsx
// Server layout → mounts a single client RuntimeRoot to avoid using next/dynamic with ssr:false in server files.

import "./_styles/emoji.css";
import "./_styles/holo.css";

import type { Metadata } from "next";
import RuntimeRoot from "./_client/runtime-root";

export const metadata: Metadata = {
  title: "Lumora",
  description: "Next-gen social-commerce-gaming-media platform.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        id="lumora-root"
        data-app="lumora"
        style={{ overscrollBehaviorY: "contain", WebkitTapHighlightColor: "transparent" }}
      >
        <noscript>Enable JavaScript for the best Lumora experience.</noscript>
        <RuntimeRoot />
        <SplashGate>{children}</SplashGate>
      </body>
    </html>
  );
}
