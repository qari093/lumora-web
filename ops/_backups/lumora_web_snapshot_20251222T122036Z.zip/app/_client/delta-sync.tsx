export default function DeltaSync() { return null; }
