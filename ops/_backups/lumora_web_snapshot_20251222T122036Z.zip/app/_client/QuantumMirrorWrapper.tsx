"use client";
import QuantumMirror from "./quantum-mirror";
export default function QuantumMirrorWrapper(){ return <QuantumMirror/>; }
