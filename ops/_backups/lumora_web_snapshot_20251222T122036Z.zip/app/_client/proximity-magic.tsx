export default function ProximityMagic() { return null; }
