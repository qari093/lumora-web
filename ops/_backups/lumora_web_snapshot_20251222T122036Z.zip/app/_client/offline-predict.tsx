export default function OfflinePredict() { return null; }
