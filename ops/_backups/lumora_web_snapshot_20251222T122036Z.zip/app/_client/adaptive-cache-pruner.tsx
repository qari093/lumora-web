export default function AdaptiveCachePruner() { return null; }
