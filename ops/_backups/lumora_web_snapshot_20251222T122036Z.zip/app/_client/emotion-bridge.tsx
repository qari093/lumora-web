export default function EmotionBridge() { return null; }
