export default function PwaRegister() { return null; }
