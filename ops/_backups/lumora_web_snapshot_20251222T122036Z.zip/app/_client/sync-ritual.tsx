export default function SyncRitual() { return null; }
