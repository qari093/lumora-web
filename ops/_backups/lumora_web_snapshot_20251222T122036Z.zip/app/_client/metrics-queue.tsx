export default function MetricsQueue() { return null; }
