export default function OfflineStateCapsule() { return null; }
