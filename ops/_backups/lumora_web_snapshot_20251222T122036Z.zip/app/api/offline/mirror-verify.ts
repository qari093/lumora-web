/**
 * NOTE: This file is intentionally a no-op placeholder for future
 * remote integrity hooks (e.g., registering snapshot headers).
 * Keeping it here to reserve the path and avoid 404 crawls.
 */
export {};
