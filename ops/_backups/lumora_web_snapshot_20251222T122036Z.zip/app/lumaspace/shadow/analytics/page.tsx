export default function LumaSpaceShadowAnalyticsPage() {
  return <div style={{ padding: 24 }}>Shadow analytics placeholder.</div>;
}
