export default function LumaSpaceForecastPage() {
  return <div style={{ padding: 24 }}>LumaSpace forecast placeholder.</div>;
}
