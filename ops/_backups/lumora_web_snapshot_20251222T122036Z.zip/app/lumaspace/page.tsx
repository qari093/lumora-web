export default function LumaSpacePage() {
  return <div style={{ padding: 24 }}>LumaSpace home placeholder.</div>;
}
