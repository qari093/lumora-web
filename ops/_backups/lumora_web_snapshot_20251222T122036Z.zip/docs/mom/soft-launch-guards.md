# Soft-launch Guard Coverage Quick-Op

This document describes the soft-launch guard coverage audit.

## Checks
- Feed/home shell guard
- Payments/wallet guard
- Ads/campaign guard
- Server guard module presence
- Runtime endpoints
