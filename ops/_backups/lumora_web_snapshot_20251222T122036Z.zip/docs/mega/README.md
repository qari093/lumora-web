# Lumora Mega Run — Harness README

This folder contains helper files for the 1520-step mega execution.

## Core Marker

- `.lumora_mega_run` — simple text marker with:
  - `MEGA_RUN_START`
  - `MEGA_TOTAL_STEPS`
  - `MEGA_LAST_COMPLETED_STEP`

## Key Docs

- `mega_run_overview.md`      — high-level overview + session logs
- `mega_step_index.md`        — indexed summary of completed steps
- `mega_status_snapshot.txt`  — snapshot of marker + docs
- `mega_run_YYYY-MM-DD.log`   — per-day run logs (one per date)
- `mega_checkpoint_step17.md` — example checkpoint doc

## Helper Scripts (in /tmp)

- `/tmp/lumora_mega_resume.sh` — quick resume harness
- `/tmp/lumora_mega_status.sh` — shows marker + progress
- `/tmp/lumora_mega_open_doc.sh` — previews + opens mega_run_overview.md
- `/tmp/lumora_mega_note.sh` — append free-form notes into mega_notes.log
- `/tmp/lumora_mega_hub.sh` (optional) — central console view if created

## Notes

- All mega artifacts are ignored by git via `.gitignore`.
- The marker `.lumora_mega_run` is the single source of truth for:
  - total steps
  - last completed step
